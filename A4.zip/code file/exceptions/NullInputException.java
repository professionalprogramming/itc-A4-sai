package hotel.exceptions;

@SuppressWarnings("serial")
public class NullInputException extends RuntimeException {

}
