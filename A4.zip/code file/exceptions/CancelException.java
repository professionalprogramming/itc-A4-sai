package hotel.exceptions;

@SuppressWarnings("serial")
public class CancelException extends RuntimeException {

}
